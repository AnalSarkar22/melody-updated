import music

if __name__ == "__main__":
    music.run_bot()